Delete a Cluster Security Group
-------------------------------

This example deletes a cluster security group.

Command::

   aws redshift delete-cluster-security-group --cluster-security-group-name mysecuritygroup

